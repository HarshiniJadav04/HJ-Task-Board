﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

using System.Collections.ObjectModel;

namespace Wpf_Knowledge_Club
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static ObservableCollection<Member> _members;
        
        private void Application_Startup(object sender, StartupEventArgs e)
        {
            _members = MyStorage.ReadXml<ObservableCollection<Member>>
             ("Members.xml");

            if (_members == null)
                _members = new ObservableCollection<Member>();
        }

        private void Application_Exit(object sender, ExitEventArgs e)
        {
            MyStorage.WriteXml<ObservableCollection<Member>>(_members, ("Members.xml"));

        }
    }
}
