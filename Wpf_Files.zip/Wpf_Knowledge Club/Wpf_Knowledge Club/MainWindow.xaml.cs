﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Wpf_Knowledge_Club
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            CultureInfo.CurrentUICulture = new CultureInfo("de");
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            CBx_gender.ItemsSource = new List<string> { "Female", "Male", "Diversity"};
            LBx_members.ItemsSource = App._members;
        }

        private void Btn_Add_Click(object sender, RoutedEventArgs e)
        {
            Member mem = new Member { Id = 12345, firstName = "Edit!", lastName = "" };
            App._members.Add(mem);
            LBx_members.SelectedItem = mem;
            LBx_members.ScrollIntoView(mem);
        }

        private void Btn_Delete_Click(object sender, RoutedEventArgs e)
        {
            var itm = LBx_members.SelectedItem as Member;
            if(itm == null)
            {
                MessageBox.Show("Please select an item to be deleted","Error",MessageBoxButton.OK,MessageBoxImage.Stop);
                return;
            }
            var res = MessageBox.Show($"Do you really want to delete\n\n{itm.firstName} {itm.lastName}?", "warning", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if(res == MessageBoxResult.Yes)
                App._members.Remove(itm);
        }

        private void Btn_Navigation_Click(object sender, RoutedEventArgs e)
        {
            var win = new W_Demo();
            win.Owner = this;
            Visibility = Visibility.Collapsed;
            win.Width = Width;
            win.Height = Height;
            win.Show();

        }

        public void TBx_filter_TextChanged(object sender, TextChangedEventArgs e)
        {
            var filter = TBx_filter.Text.ToLower();
            if (filter == "")
                LBx_members.ItemsSource = App._members;
            else
            {
                var lst = (from b in App._members where b.lastName.StartsWith(filter,StringComparison.InvariantCultureIgnoreCase) select b).ToList();
                var lst2 = (from m in App._members where m.lastName.ToLower().Contains(filter) select m).ToList();
                lst.AddRange(lst2);
                LBx_members.ItemsSource = lst.Distinct();

            }
        }
    }
}
