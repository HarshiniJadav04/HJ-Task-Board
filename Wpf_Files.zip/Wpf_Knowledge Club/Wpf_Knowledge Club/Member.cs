﻿using System;

namespace Wpf_Knowledge_Club
{
    public class Member
    {
        public int Id { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public DateTime birthDate { get; set; }
        public DateTime applicationDate { get; set; }
        public DateTime membershipdate { get; set; }
        public int gender { get; set; } //0:Female, 1: Male, 2:Diversity
        public string hobbies { get; set; }
        public string languages { get; set; }
        public string knowledge { get; set; }
        public string image { get; set; }
        public bool status  { get; set; } //active or not
        public DateTime statusDate { get; set; }
        public string statusHint { get; set; }

    }
}