﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace Wpf_Knowledge_Club
{
    public class String2ImagePath : IValueConverter
    { 
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if(value == null)
        {
            return $"/Knowledge-transfer.png";
        }
            else
        {
            if (File.Exists(value.ToString()))
                return value;
            else
                return $"/Knowledge-transfer.png";
        }

        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
    public class Int2String : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
                switch ((int)value)
                {
                    case 0: return "Female";
                    case 1: return "Male";
                    case 2: return "Diversity";
                }
                return null;
            }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            switch (value.ToString()[0])
            {
                case 'F': return 0;
                case 'M': return 1;
                case 'D': return 2;
            }
            return null;
        }
    }

}
