﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace Wpf_Smart_Data
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static List<Name> _namesInput;
        public void Application_startup(object sender, StartupEventArgs e)
        {
            /*
            _namesInput = new List<Name> { new Name { name="XXX", gender=true}, new Name { name = "YYY", gender = true }, new Name { name = "ZZZ", gender = true } };
            MyStorage.WriteXml<List<Name>>(_namesInput, "NamesInput.xml");
        */
            _namesInput = MyStorage.ReadXml<List<Name>>("NamesInput.xml");
            if(_namesInput == null)
                _namesInput = new List<Name>();
            }
    }
}
