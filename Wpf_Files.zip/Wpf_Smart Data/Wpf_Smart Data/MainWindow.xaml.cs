﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Wpf_Smart_Data
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Student> Students = new List<Student>();
        public MainWindow()
        {
            InitializeComponent();
        }


        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            var cnt = Convert.ToInt32(TBx_Count.Text);
            int matNr = Convert.ToInt32(TBx_matNr.Text);
            Students = GenerateStudents(cnt, matNr);
            MyStorage.WriteXml<List<Student>>(Students, "Studentsdata.xml");

            LBx_Students.ItemsSource = Students;
        }

        private List<Student> GenerateStudents(int cnt, int matNum)
        {
            Random rnd = new Random();
            var stu = new List<Student>();
            for (int i = 0; i < cnt; i++)
            {
                //var gnd = rnd.Next(2) == 0 ? true : false;
                Name name = App._namesInput[rnd.Next(App._namesInput.Count)];
                //stu.Add(new Student { matNr = matNum, firstName = $"SFirstName {i}", lastName = $"SLastName {i}", gender = gnd });
                stu.Add(new Student { matNr = matNum, firstName = name.name, lastName = name.name, gender = name.gender });
                matNum++;
            }
            return stu;
        }
    }
}
