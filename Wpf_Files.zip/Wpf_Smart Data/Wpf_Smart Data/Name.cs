﻿namespace Wpf_Smart_Data
{
    public class Name
    {
        public string name { get; set; }
        public bool gender { get; set; }
    }
}