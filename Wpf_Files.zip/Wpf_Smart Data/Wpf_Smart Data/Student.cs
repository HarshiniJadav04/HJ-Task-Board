﻿namespace Wpf_Smart_Data
{
    public class Student
    {
        public int matNr { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public bool gender { get; set; }
    }
}